<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/check_email', 'HomeController@check_email')->name('check_email');
Route::get('/usersList', 'HomeController@usersList')->name('usersList');

Route::group(['middleware' => ['auth'], 'prefix' => 'admin', 'namespace' => 'Admin'], function () {
    /* For manage dashboard */
    Route::get('/dashboard', 'AdminController@index')->name('admin-dashboard');

    /* For manage users */
    Route::get('users', 'UserController@usersList')->name('admin.users');
    Route::get('users/create', 'UserController@createUser')->name('admin.user.add');
    Route::post('users/create', 'UserController@saveUser')->name('admin.user.save');
    Route::get('users/{id}/edit', 'UserController@editUser')->name('admin.user.edit');
    Route::post('users/{id}/edit', 'UserController@updateUser')->name('admin.user.update');
    Route::get('users/{id}/delete', 'UserController@deleteUser')->name('admin.user.delete');

});