<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       // $this->middleware('auth');
       $this->record_per_page=10;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    public function check_email(Request $request) {
        $email = strtolower(trim($request->email));
        $id = strtolower(trim($request->id));
        $user = User::where('email', '=', $email);
        if($id){
            $user->where('id', '!=', $id);
        }
        $user = $user->first();    
        if (!empty($user)) {
            return 'false';
        }else{
            return 'true';
        }
    } 

    public function usersList(Request $request) {
        
        DB::enableQueryLog();
        
        $usersList = User::where('users.email', '!=', '')->where('users.is_deleted', '=', '0')->get()->toarray();
        
        $queries = DB::getQueryLog();
        
        return $usersList;
    }
}
